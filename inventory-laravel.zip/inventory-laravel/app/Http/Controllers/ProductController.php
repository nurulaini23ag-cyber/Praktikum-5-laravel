<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product;
use App\Models\StockMovement;
use App\Models\Supplier;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource with search, filter, sorting, and pagination.
     */
    public function index(Request $request)
    {
        $allowedSorts = ['name', 'sku', 'price', 'stock', 'created_at'];
        $sortBy = in_array($request->sort, $allowedSorts) ? $request->sort : 'name';
        $sortOrder = in_array(strtolower($request->order), ['asc', 'desc']) ? strtolower($request->order) : 'asc';

        $products = Product::with(['category', 'suppliers'])
            ->when($request->search, function ($query, $search) {
                $query->where(function ($q) use ($search) {
                    $q->where('name', 'like', "%{$search}%")
                      ->orWhere('sku', 'like', "%{$search}%");
                });
            })
            ->when($request->category_id, function ($query, $categoryId) {
                $query->where('category_id', $categoryId);
            })
            ->when($request->stock_status === 'low', function ($query) {
                $query->whereColumn('stock', '<=', 'minimum_stock');
            })
            ->orderBy($sortBy, $sortOrder)
            ->paginate(10)
            ->withQueryString();

        $categories = Category::orderBy('name')->get();

        return view('products.index', compact('products', 'categories', 'sortBy', 'sortOrder'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $categories = Category::orderBy('name')->get();
        $suppliers = Supplier::orderBy('name')->get();

        return view('products.create', compact('categories', 'suppliers'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'category_id'   => ['required', 'exists:categories,id'],
            'sku'           => ['required', 'string', 'max:50', 'unique:products,sku'],
            'name'          => ['required', 'string', 'max:150'],
            'price'         => ['required', 'numeric', 'min:0'],
            'stock'         => ['required', 'integer', 'min:0'],
            'minimum_stock' => ['required', 'integer', 'min:0'],
            'supplier_id'   => ['nullable', 'exists:suppliers,id'],
            'supplier_price'=> ['nullable', 'numeric', 'min:0'],
        ]);

        DB::transaction(function () use ($validated, $request) {
            $product = Product::create([
                'category_id'   => $validated['category_id'],
                'sku'           => strtoupper(trim($validated['sku'])),
                'name'          => trim($validated['name']),
                'price'         => $validated['price'],
                'stock'         => $validated['stock'],
                'minimum_stock' => $validated['minimum_stock'],
            ]);

            // Hubungkan supplier bila dipilih
            if (!empty($validated['supplier_id'])) {
                $product->suppliers()->attach($validated['supplier_id'], [
                    'supplier_price' => $validated['supplier_price'] ?? $validated['price'],
                ]);
            }

            // Catat pergerakan stok awal jika stok > 0
            if ($validated['stock'] > 0) {
                StockMovement::create([
                    'product_id' => $product->id,
                    'user_id'    => auth()->id(),
                    'type'       => 'IN',
                    'quantity'   => $validated['stock'],
                    'notes'      => 'Stok awal penambahan produk',
                ]);
            }
        });

        return redirect()->route('products.index')
            ->with('success', 'Produk berhasil ditambahkan.');
    }

    /**
     * Display the specified resource.
     */
    public function show(Product $product)
    {
        $product->load(['category', 'suppliers', 'stockMovements.user']);

        return view('products.show', compact('product'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Product $product)
    {
        $categories = Category::orderBy('name')->get();
        $suppliers = Supplier::orderBy('name')->get();
        $product->load('suppliers');

        return view('products.edit', compact('product', 'categories', 'suppliers'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Product $product)
    {
        $validated = $request->validate([
            'category_id'   => ['required', 'exists:categories,id'],
            'sku'           => ['required', 'string', 'max:50', Rule::unique('products', 'sku')->ignore($product->id)],
            'name'          => ['required', 'string', 'max:150'],
            'price'         => ['required', 'numeric', 'min:0'],
            'stock'         => ['required', 'integer', 'min:0'],
            'minimum_stock' => ['required', 'integer', 'min:0'],
            'supplier_id'   => ['nullable', 'exists:suppliers,id'],
            'supplier_price'=> ['nullable', 'numeric', 'min:0'],
        ]);

        DB::transaction(function () use ($validated, $product) {
            $oldStock = $product->stock;
            $newStock = $validated['stock'];

            $product->update([
                'category_id'   => $validated['category_id'],
                'sku'           => strtoupper(trim($validated['sku'])),
                'name'          => trim($validated['name']),
                'price'         => $validated['price'],
                'stock'         => $newStock,
                'minimum_stock' => $validated['minimum_stock'],
            ]);

            if (isset($validated['supplier_id'])) {
                if ($validated['supplier_id']) {
                    $product->suppliers()->sync([
                        $validated['supplier_id'] => ['supplier_price' => $validated['supplier_price'] ?? $validated['price']]
                    ]);
                } else {
                    $product->suppliers()->detach();
                }
            }

            // Catat perubahan stok bila ada penyesuaian manual
            if ($newStock !== $oldStock) {
                $diff = $newStock - $oldStock;
                StockMovement::create([
                    'product_id' => $product->id,
                    'user_id'    => auth()->id(),
                    'type'       => $diff > 0 ? 'IN' : 'OUT',
                    'quantity'   => abs($diff),
                    'notes'      => 'Penyesuaian stok manual dari halaman edit produk',
                ]);
            }
        });

        return redirect()->route('products.index')
            ->with('success', 'Produk berhasil diperbarui.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Product $product)
    {
        // Business Rule: RESTRICT delete bila produk memiliki riwayat transaksi pergerakan stok
        if ($product->stockMovements()->count() > 0) {
            return redirect()->route('products.index')
                ->with('error', 'Produk tidak dapat dihapus karena memiliki riwayat pergerakan stok.');
        }

        $product->suppliers()->detach();
        $product->delete();

        return redirect()->route('products.index')
            ->with('success', 'Produk berhasil dihapus.');
    }
}
