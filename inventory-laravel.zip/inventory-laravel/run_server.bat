@echo off
setlocal
title Inventory Management System - Laravel (P5)

echo ===================================================================
echo   Inventory Management System - Laravel Fundamental (Pertemuan 5)
echo ===================================================================
echo.

:: 1. Pastikan folder PHP dan PHPRC terdaftar
set "PHPRC=C:\Users\nurul\php"
set "PATH=C:\Users\nurul\php;%PATH%"

:: 2. Cek apakah MySQL XAMPP sudah berjalan, jika belum jalankan otomatis di background
echo [1/3] Memeriksa koneksi database MySQL (port 3306)...
netstat -ano | findstr :3306 | findstr LISTENING >nul
if %errorlevel% neq 0 (
    echo [INFO] Menjalankan MySQL dari XAMPP...
    start "" /b "C:\xampp\mysql\bin\mysqld.exe" --defaults-file="C:\xampp\mysql\bin\my.ini" --standalone
    timeout /t 2 /nobreak >nul
) else (
    echo [OK] MySQL sudah aktif di port 3306.
)

:: 3. Otomatis buka web browser
echo [2/3] Membuka browser ke http://127.0.0.1:8000 ...
start http://127.0.0.1:8000

:: 4. Jalankan Laravel Development Server
echo [3/3] Menjalankan web server Laravel...
echo.
echo ===================================================================
echo   Aplikasi aktif di: http://127.0.0.1:8000
echo   Kredensial Demo:
echo     - Admin : admin / admin123
echo     - Staff : staff / staff123
echo   (Tekan CTRL+C untuk menghentikan server)
echo ===================================================================
echo.

php -c "C:\Users\nurul\php\php.ini" artisan serve --host=127.0.0.1 --port=8000 --no-reload

pause
