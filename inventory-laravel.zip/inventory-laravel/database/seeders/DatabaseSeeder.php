<?php

namespace Database\Seeders;

use App\Models\Category;
use App\Models\Product;
use App\Models\StockMovement;
use App\Models\Supplier;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // 1. Seed Users (P4 Accounts)
        $admin = User::firstOrCreate(
            ['email' => 'admin@inventory.com'],
            [
                'name' => 'Administrator',
                'username' => 'admin',
                'password' => Hash::make('admin123'),
                'role' => 'admin',
            ]
        );

        $staff = User::firstOrCreate(
            ['email' => 'staff@inventory.com'],
            [
                'name' => 'Staff Gudang',
                'username' => 'staff',
                'password' => Hash::make('staff123'),
                'role' => 'staff',
            ]
        );

        // 2. Seed Master Categories from P4
        $catElectronics = Category::firstOrCreate(
            ['name' => 'Elektronik'],
            ['description' => 'Peralatan dan peranti elektronik']
        );
        $catAccessories = Category::firstOrCreate(
            ['name' => 'Aksesoris Komputer'],
            ['description' => 'Perlengkapan pendukung PC/Laptop']
        );
        $catStationery = Category::firstOrCreate(
            ['name' => 'Alat Tulis Kantor'],
            ['description' => 'Kebutuhan administrasi kantor']
        );

        // 3. Seed Suppliers from P4
        $supplier1 = Supplier::firstOrCreate(
            ['name' => 'PT Tech Distro Utama'],
            [
                'contact_info' => 'Budi Santoso',
                'phone' => '08123456789',
                'email' => 'budi@techdistro.id',
            ]
        );
        $supplier2 = Supplier::firstOrCreate(
            ['name' => 'CV Stationary Abadi'],
            [
                'contact_info' => 'Siti Rahma',
                'phone' => '08987654321',
                'email' => 'sales@stationaryabadi.com',
            ]
        );

        // 4. Seed Products from P4
        $p1 = Product::firstOrCreate(
            ['sku' => 'ELEC-001'],
            [
                'category_id' => $catElectronics->id,
                'name' => 'Monitor Gaming 24 Inch',
                'price' => 2100000.00,
                'stock' => 15,
                'minimum_stock' => 5,
            ]
        );
        $p2 = Product::firstOrCreate(
            ['sku' => 'ACC-001'],
            [
                'category_id' => $catAccessories->id,
                'name' => 'Keyboard Mekanikal RGB',
                'price' => 450000.00,
                'stock' => 3,
                'minimum_stock' => 5,
            ]
        );
        $p3 = Product::firstOrCreate(
            ['sku' => 'ACC-002'],
            [
                'category_id' => $catAccessories->id,
                'name' => 'Mouse Wireless Silent',
                'price' => 120000.00,
                'stock' => 25,
                'minimum_stock' => 10,
            ]
        );
        $p4 = Product::firstOrCreate(
            ['sku' => 'ATK-001'],
            [
                'category_id' => $catStationery->id,
                'name' => 'Kertas HVS A4 80gr (Ream)',
                'price' => 48000.00,
                'stock' => 2,
                'minimum_stock' => 8,
            ]
        );

        // Attach suppliers to products
        $p1->suppliers()->syncWithoutDetaching([$supplier1->id => ['supplier_price' => 1850000.00]]);
        $p2->suppliers()->syncWithoutDetaching([$supplier1->id => ['supplier_price' => 380000.00]]);
        $p3->suppliers()->syncWithoutDetaching([$supplier1->id => ['supplier_price' => 95000.00]]);
        $p4->suppliers()->syncWithoutDetaching([$supplier2->id => ['supplier_price' => 40000.00]]);

        // Initial Stock Movements from P4
        StockMovement::firstOrCreate([
            'product_id' => $p1->id,
            'user_id' => $admin->id,
            'type' => 'IN',
            'quantity' => 15,
            'notes' => 'Stok awal pembukaan gudang',
        ]);
        StockMovement::firstOrCreate([
            'product_id' => $p2->id,
            'user_id' => $admin->id,
            'type' => 'IN',
            'quantity' => 10,
            'notes' => 'Stok awal pembukaan gudang',
        ]);
        StockMovement::firstOrCreate([
            'product_id' => $p2->id,
            'user_id' => $staff->id,
            'type' => 'OUT',
            'quantity' => 7,
            'notes' => 'Penjualan toko online',
        ]);
        StockMovement::firstOrCreate([
            'product_id' => $p3->id,
            'user_id' => $admin->id,
            'type' => 'IN',
            'quantity' => 25,
            'notes' => 'Stok awal pembukaan gudang',
        ]);
        StockMovement::firstOrCreate([
            'product_id' => $p4->id,
            'user_id' => $admin->id,
            'type' => 'IN',
            'quantity' => 10,
            'notes' => 'Stok awal pembukaan gudang',
        ]);
        StockMovement::firstOrCreate([
            'product_id' => $p4->id,
            'user_id' => $staff->id,
            'type' => 'OUT',
            'quantity' => 8,
            'notes' => 'Penggunaan internal kantor',
        ]);

        // 5. Seed Factories as specified in Slide 30
        Category::factory(5)->create();
        Product::factory(50)->create();
    }
}
