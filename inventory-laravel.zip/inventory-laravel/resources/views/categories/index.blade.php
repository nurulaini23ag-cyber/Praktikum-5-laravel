@extends('layouts.app')

@section('content')
<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
    <div>
        <h1 style="font-size: 1.75rem; font-weight: 700; margin: 0; color: #0f172a;">Manajemen Kategori</h1>
        <p style="color: #64748b; margin: 0.25rem 0 0 0; font-size: 0.875rem;">Relasi One-to-Many dengan produk inventaris.</p>
    </div>
</div>

<div style="display: grid; grid-template-columns: 1fr 2fr; gap: 1.5rem;">
    <!-- Form Tambah Kategori -->
    <div class="card" style="height: fit-content;">
        <h3 style="font-size: 1.1rem; font-weight: 600; margin-top: 0; margin-bottom: 1rem; color: #1e293b;">+ Tambah Kategori</h3>
        <form method="POST" action="{{ route('categories.store') }}">
            @csrf
            <div class="form-group">
                <label class="form-label" for="name">Nama Kategori <span style="color: #dc2626;">*</span></label>
                <input type="text" name="name" id="name" class="form-control @error('name') is-invalid @enderror" value="{{ old('name') }}" placeholder="Contoh: Perangkat Jaringan" required>
                @error('name')
                    <span class="invalid-feedback">{{ $message }}</span>
                @enderror
            </div>
            <div class="form-group">
                <label class="form-label" for="description">Deskripsi</label>
                <textarea name="description" id="description" rows="3" class="form-control @error('description') is-invalid @enderror" placeholder="Keterangan singkat kategori...">{{ old('description') }}</textarea>
                @error('description')
                    <span class="invalid-feedback">{{ $message }}</span>
                @enderror
            </div>
            <button type="submit" class="btn btn-primary" style="width: 100%; justify-content: center;">Simpan Kategori</button>
        </form>
    </div>

    <!-- Tabel Daftar Kategori -->
    <div class="card" style="padding: 0; overflow: hidden;">
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Nama Kategori</th>
                        <th>Deskripsi</th>
                        <th style="text-align: center; width: 110px;">Jml Produk</th>
                        <th style="text-align: right; width: 100px;">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($categories as $category)
                        <tr>
                            <td style="font-weight: 600; color: #0f172a;">{{ $category->name }}</td>
                            <td style="color: #64748b;">{{ $category->description ?? '-' }}</td>
                            <td style="text-align: center;">
                                <a href="{{ route('products.index', ['category_id' => $category->id]) }}" class="badge badge-info" style="text-decoration: none;">
                                    {{ $category->products_count }} produk
                                </a>
                            </td>
                            <td style="text-align: right;">
                                <form action="{{ route('categories.destroy', $category) }}" method="POST" style="margin: 0;" onsubmit="return confirm('Hapus kategori ini?');">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;">Hapus</button>
                                </form>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="4" style="text-align: center; color: #94a3b8; padding: 2rem;">Belum ada data kategori.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        <div style="padding: 1rem;">
            {{ $categories->links() }}
        </div>
    </div>
</div>
@endsection
