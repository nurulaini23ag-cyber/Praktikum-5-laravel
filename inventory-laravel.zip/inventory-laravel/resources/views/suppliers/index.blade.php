@extends('layouts.app')

@section('content')
<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
    <div>
        <h1 style="font-size: 1.75rem; font-weight: 700; margin: 0; color: #0f172a;">Manajemen Supplier</h1>
        <p style="color: #64748b; margin: 0.25rem 0 0 0; font-size: 0.875rem;">Relasi Many-to-Many dengan produk melalui pivot tabel.</p>
    </div>
</div>

<div style="display: grid; grid-template-columns: 1fr 2fr; gap: 1.5rem;">
    <!-- Form Tambah Supplier -->
    <div class="card" style="height: fit-content;">
        <h3 style="font-size: 1.1rem; font-weight: 600; margin-top: 0; margin-bottom: 1rem; color: #1e293b;">+ Tambah Supplier</h3>
        <form method="POST" action="{{ route('suppliers.store') }}">
            @csrf
            <div class="form-group">
                <label class="form-label" for="name">Nama Perusahaan / Supplier <span style="color: #dc2626;">*</span></label>
                <input type="text" name="name" id="name" class="form-control @error('name') is-invalid @enderror" value="{{ old('name') }}" placeholder="Contoh: PT Sumber Makmur" required>
                @error('name')
                    <span class="invalid-feedback">{{ $message }}</span>
                @enderror
            </div>
            <div class="form-group">
                <label class="form-label" for="contact_info">Kontak Person</label>
                <input type="text" name="contact_info" id="contact_info" class="form-control @error('contact_info') is-invalid @enderror" value="{{ old('contact_info') }}" placeholder="Nama PIC">
                @error('contact_info')
                    <span class="invalid-feedback">{{ $message }}</span>
                @enderror
            </div>
            <div class="form-group">
                <label class="form-label" for="phone">Nomor Telepon</label>
                <input type="text" name="phone" id="phone" class="form-control @error('phone') is-invalid @enderror" value="{{ old('phone') }}" placeholder="0812xxxx">
                @error('phone')
                    <span class="invalid-feedback">{{ $message }}</span>
                @enderror
            </div>
            <div class="form-group">
                <label class="form-label" for="email">Email</label>
                <input type="email" name="email" id="email" class="form-control @error('email') is-invalid @enderror" value="{{ old('email') }}" placeholder="supplier@example.com">
                @error('email')
                    <span class="invalid-feedback">{{ $message }}</span>
                @enderror
            </div>
            <button type="submit" class="btn btn-primary" style="width: 100%; justify-content: center;">Simpan Supplier</button>
        </form>
    </div>

    <!-- Tabel Daftar Supplier -->
    <div class="card" style="padding: 0; overflow: hidden;">
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Nama Supplier</th>
                        <th>Kontak PIC</th>
                        <th>Telepon &amp; Email</th>
                        <th style="text-align: center; width: 100px;">Produk</th>
                        <th style="text-align: right; width: 90px;">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($suppliers as $supplier)
                        <tr>
                            <td style="font-weight: 600; color: #0f172a;">{{ $supplier->name }}</td>
                            <td>{{ $supplier->contact_info ?? '-' }}</td>
                            <td>
                                <div>{{ $supplier->phone ?? '-' }}</div>
                                <div style="font-size: 0.75rem; color: #64748b;">{{ $supplier->email ?? '-' }}</div>
                            </td>
                            <td style="text-align: center;">
                                <span class="badge badge-info">{{ $supplier->products_count }} item</span>
                            </td>
                            <td style="text-align: right;">
                                <form action="{{ route('suppliers.destroy', $supplier) }}" method="POST" style="margin: 0;" onsubmit="return confirm('Hapus supplier ini?');">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;">Hapus</button>
                                </form>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="5" style="text-align: center; color: #94a3b8; padding: 2rem;">Belum ada data supplier.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        <div style="padding: 1rem;">
            {{ $suppliers->links() }}
        </div>
    </div>
</div>
@endsection
