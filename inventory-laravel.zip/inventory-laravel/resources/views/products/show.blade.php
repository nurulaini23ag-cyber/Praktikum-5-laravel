@extends('layouts.app')

@section('content')
<div style="max-width: 900px; margin: 0 auto;">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem;">
        <div>
            <h1 style="font-size: 1.75rem; font-weight: 700; margin: 0; color: #0f172a;">{{ $product->name }}</h1>
            <p style="color: #64748b; margin: 0.25rem 0 0 0; font-size: 0.875rem;">SKU: <span style="font-family: monospace; font-weight: 600; color: #2563eb;">{{ $product->sku }}</span></p>
        </div>
        <div style="display: flex; gap: 0.5rem;">
            <a href="{{ route('products.index') }}" class="btn btn-secondary">&larr; Kembali</a>
            <a href="{{ route('products.edit', $product) }}" class="btn btn-primary">Edit Produk</a>
        </div>
    </div>

    <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 1.5rem; margin-bottom: 1.5rem;">
        <div class="card" style="margin-bottom: 0;">
            <h3 style="font-size: 1.1rem; font-weight: 600; margin-top: 0; margin-bottom: 1rem; border-bottom: 1px solid #f1f5f9; padding-bottom: 0.5rem;">Informasi Detail</h3>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                <div>
                    <span style="font-size: 0.8125rem; color: #64748b; display: block;">Kategori</span>
                    <strong style="font-size: 1rem; color: #1e293b;">{{ $product->category->name ?? '-' }}</strong>
                </div>
                <div>
                    <span style="font-size: 0.8125rem; color: #64748b; display: block;">Harga Jual</span>
                    <strong style="font-size: 1rem; color: #059669;">Rp {{ number_format($product->price, 0, ',', '.') }}</strong>
                </div>
                <div>
                    <span style="font-size: 0.8125rem; color: #64748b; display: block;">Stok Saat Ini</span>
                    <strong style="font-size: 1.25rem; color: {{ $product->stock <= $product->minimum_stock ? '#dc2626' : '#2563eb' }};">{{ $product->stock }}</strong>
                </div>
                <div>
                    <span style="font-size: 0.8125rem; color: #64748b; display: block;">Batas Minimum Stok</span>
                    <strong style="font-size: 1rem; color: #1e293b;">{{ $product->minimum_stock }}</strong>
                </div>
            </div>

            <div style="margin-top: 1.5rem;">
                <h4 style="font-size: 0.95rem; font-weight: 600; margin-bottom: 0.5rem; color: #475569;">Penyuplai Terkait (Many-to-Many):</h4>
                @if($product->suppliers->count() > 0)
                    <div style="display: flex; flex-direction: column; gap: 0.5rem;">
                        @foreach($product->suppliers as $sup)
                            <div style="padding: 0.5rem 0.75rem; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; display: flex; justify-content: space-between; align-items: center;">
                                <div>
                                    <strong>{{ $sup->name }}</strong>
                                    <span style="color: #64748b; font-size: 0.8125rem; display: block;">{{ $sup->phone }} | {{ $sup->email }}</span>
                                </div>
                                <span style="font-size: 0.875rem; color: #475569;">
                                    Harga Pasokan: <strong>Rp {{ number_format($sup->pivot->supplier_price ?? 0, 0, ',', '.') }}</strong>
                                </span>
                            </div>
                        @endforeach
                    </div>
                @else
                    <p style="color: #94a3b8; font-size: 0.875rem; margin: 0;">Tidak ada supplier yang terhubung.</p>
                @endif
            </div>
        </div>

        <div class="card" style="margin-bottom: 0;">
            <h3 style="font-size: 1.1rem; font-weight: 600; margin-top: 0; margin-bottom: 1rem; border-bottom: 1px solid #f1f5f9; padding-bottom: 0.5rem;">Aksi Cepat Mutasi</h3>
            <div style="display: flex; flex-direction: column; gap: 0.75rem;">
                <a href="{{ route('stock.in') }}?product_id={{ $product->id }}" class="btn btn-success" style="justify-content: center;">+ Tambah Stok Masuk</a>
                <a href="{{ route('stock.out') }}?product_id={{ $product->id }}" class="btn btn-danger" style="justify-content: center;">- Catat Stok Keluar</a>
            </div>
        </div>
    </div>

    <!-- Riwayat Pergerakan Stok untuk Produk Ini -->
    <div class="card" style="padding: 0; overflow: hidden;">
        <div style="padding: 1rem 1.25rem; border-bottom: 1px solid #e2e8f0; background: #f8fafc;">
            <h3 style="margin: 0; font-size: 1rem; font-weight: 600; color: #1e293b;">Riwayat Transaksi Mutasi Produk</h3>
        </div>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Waktu</th>
                        <th>Tipe</th>
                        <th style="text-align: center;">Jumlah</th>
                        <th>Petugas</th>
                        <th>Keterangan</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($product->stockMovements as $mv)
                        <tr>
                            <td>{{ $mv->created_at->format('d/m/Y H:i') }}</td>
                            <td>
                                @if($mv->type === 'IN')
                                    <span class="badge badge-success">+ MASUK</span>
                                @else
                                    <span class="badge badge-danger">- KELUAR</span>
                                @endif
                            </td>
                            <td style="text-align: center; font-weight: 600;">{{ $mv->quantity }}</td>
                            <td>{{ $mv->user->name ?? 'System' }}</td>
                            <td style="color: #64748b;">{{ $mv->notes ?? '-' }}</td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="5" style="text-align: center; color: #94a3b8; padding: 2rem;">Belum ada catatan mutasi stok untuk produk ini.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection
