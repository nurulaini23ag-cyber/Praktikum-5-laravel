@extends('layouts.app')

@section('content')
<div style="max-width: 700px; margin: 0 auto;">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
        <div>
            <h1 style="font-size: 1.75rem; font-weight: 700; margin: 0; color: #0f172a;">Tambah Produk Baru</h1>
            <p style="color: #64748b; margin: 0.25rem 0 0 0; font-size: 0.875rem;">Isi formulir berikut untuk mendaftarkan barang baru ke sistem.</p>
        </div>
        <a href="{{ route('products.index') }}" class="btn btn-secondary">&larr; Kembali</a>
    </div>

    <div class="card">
        <form method="POST" action="{{ route('products.store') }}">
            @csrf

            <div class="form-group">
                <label class="form-label" for="category_id">Kategori Produk <span style="color: #dc2626;">*</span></label>
                <select name="category_id" id="category_id" class="form-select @error('category_id') is-invalid @enderror" required>
                    <option value="">-- Pilih Kategori --</option>
                    @foreach($categories as $category)
                        <option value="{{ $category->id }}" {{ old('category_id') == $category->id ? 'selected' : '' }}>
                            {{ $category->name }}
                        </option>
                    @endforeach
                </select>
                @error('category_id')
                    <span class="invalid-feedback">{{ $message }}</span>
                @enderror
            </div>

            <div style="display: grid; grid-template-columns: 1fr 2fr; gap: 1rem;">
                <div class="form-group">
                    <label class="form-label" for="sku">SKU / Kode Produk <span style="color: #dc2626;">*</span></label>
                    <input type="text" name="sku" id="sku" class="form-control @error('sku') is-invalid @enderror" value="{{ old('sku') }}" placeholder="Contoh: ELEC-002" required>
                    @error('sku')
                        <span class="invalid-feedback">{{ $message }}</span>
                    @enderror
                </div>
                <div class="form-group">
                    <label class="form-label" for="name">Nama Produk <span style="color: #dc2626;">*</span></label>
                    <input type="text" name="name" id="name" class="form-control @error('name') is-invalid @enderror" value="{{ old('name') }}" placeholder="Contoh: Wireless Mechanical Keyboard" required>
                    @error('name')
                        <span class="invalid-feedback">{{ $message }}</span>
                    @enderror
                </div>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 1rem;">
                <div class="form-group">
                    <label class="form-label" for="price">Harga Jual (Rp) <span style="color: #dc2626;">*</span></label>
                    <input type="number" step="0.01" name="price" id="price" class="form-control @error('price') is-invalid @enderror" value="{{ old('price') }}" placeholder="0" min="0" required>
                    @error('price')
                        <span class="invalid-feedback">{{ $message }}</span>
                    @enderror
                </div>
                <div class="form-group">
                    <label class="form-label" for="stock">Stok Awal <span style="color: #dc2626;">*</span></label>
                    <input type="number" name="stock" id="stock" class="form-control @error('stock') is-invalid @enderror" value="{{ old('stock', 0) }}" min="0" required>
                    @error('stock')
                        <span class="invalid-feedback">{{ $message }}</span>
                    @enderror
                </div>
                <div class="form-group">
                    <label class="form-label" for="minimum_stock">Batas Minimum Stok <span style="color: #dc2626;">*</span></label>
                    <input type="number" name="minimum_stock" id="minimum_stock" class="form-control @error('minimum_stock') is-invalid @enderror" value="{{ old('minimum_stock', 5) }}" min="0" required>
                    @error('minimum_stock')
                        <span class="invalid-feedback">{{ $message }}</span>
                    @enderror
                </div>
            </div>

            <div style="background: #f8fafc; padding: 1rem; border-radius: 6px; border: 1px dashed #cbd5e1; margin-bottom: 1.5rem;">
                <h4 style="margin: 0 0 0.75rem 0; font-size: 0.9rem; color: #475569;">Penyuplai / Supplier (Opsional)</h4>
                <div style="display: grid; grid-template-columns: 1.5fr 1fr; gap: 1rem;">
                    <div>
                        <label class="form-label" for="supplier_id">Nama Supplier</label>
                        <select name="supplier_id" id="supplier_id" class="form-select @error('supplier_id') is-invalid @enderror">
                            <option value="">-- Tanpa Supplier --</option>
                            @foreach($suppliers as $supplier)
                                <option value="{{ $supplier->id }}" {{ old('supplier_id') == $supplier->id ? 'selected' : '' }}>
                                    {{ $supplier->name }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div>
                        <label class="form-label" for="supplier_price">Harga Beli Supplier (Rp)</label>
                        <input type="number" step="0.01" name="supplier_price" id="supplier_price" class="form-control" value="{{ old('supplier_price') }}" placeholder="0" min="0">
                    </div>
                </div>
            </div>

            <div style="display: flex; justify-content: flex-end; gap: 0.75rem;">
                <a href="{{ route('products.index') }}" class="btn btn-secondary">Batal</a>
                <button type="submit" class="btn btn-primary">Simpan Produk</button>
            </div>
        </form>
    </div>
</div>
@endsection
