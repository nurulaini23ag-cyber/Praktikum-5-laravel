<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\StockMovementController;
use App\Http\Controllers\SupplierController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes (Pertemuan 5 - Laravel Fundamental)
|--------------------------------------------------------------------------
*/

// Dashboard Statistik Ringkas
Route::get('/', [DashboardController::class, 'index'])->name('dashboard');

// Autentikasi Pengguna (Admin & Staff)
Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
Route::post('/login', [AuthController::class, 'login'])->name('login.post');
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

// Resource Controller Produk (Slide 12, 14, 15, 16, 18, 38)
Route::resource('products', ProductController::class);

// Master Kategori & Supplier (Slide 16, 37)
Route::resource('categories', CategoryController::class);
Route::resource('suppliers', SupplierController::class);

// Transaksi Mutasi Stok (IN / OUT / Histori Audit Trail - Slide 37, 41)
Route::prefix('stock')->name('stock.')->group(function () {
    Route::get('/history', [StockMovementController::class, 'history'])->name('history');
    Route::get('/in', [StockMovementController::class, 'createIn'])->name('in');
    Route::post('/in', [StockMovementController::class, 'storeIn'])->name('in.store');
    Route::get('/out', [StockMovementController::class, 'createOut'])->name('out');
    Route::post('/out', [StockMovementController::class, 'storeOut'])->name('out.store');
});
