<?php $__env->startSection('content'); ?>
<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem;">
    <div>
        <h1 style="font-size: 1.75rem; font-weight: 700; margin: 0; color: #0f172a;">Riwayat Mutasi Stok</h1>
        <p style="color: #64748b; margin: 0.25rem 0 0 0; font-size: 0.875rem;">Audit trail seluruh transaksi stok masuk dan keluar gudang.</p>
    </div>
    <div style="display: flex; gap: 0.5rem;">
        <a href="<?php echo e(route('stock.in')); ?>" class="btn btn-success">+ Stok Masuk</a>
        <a href="<?php echo e(route('stock.out')); ?>" class="btn btn-danger">- Stok Keluar</a>
    </div>
</div>

<div class="card" style="padding: 1.25rem; margin-bottom: 1.5rem;">
    <form method="GET" action="<?php echo e(route('stock.history')); ?>" style="display: grid; grid-template-columns: 2fr 1.5fr 100px; gap: 0.75rem; align-items: end;">
        <div>
            <label class="form-label">Cari Nama / SKU Produk</label>
            <input type="text" name="search" class="form-control" placeholder="Ketik kata kunci..." value="<?php echo e(request('search')); ?>">
        </div>
        <div>
            <label class="form-label">Tipe Transaksi</label>
            <select name="type" class="form-select">
                <option value="">Semua Tipe (IN &amp; OUT)</option>
                <option value="IN" <?php echo e(request('type') == 'IN' ? 'selected' : ''); ?>>Stok Masuk (IN)</option>
                <option value="OUT" <?php echo e(request('type') == 'OUT' ? 'selected' : ''); ?>>Stok Keluar (OUT)</option>
            </select>
        </div>
        <div>
            <button type="submit" class="btn btn-primary" style="width: 100%; justify-content: center;">Filter</button>
        </div>
    </form>
</div>

<div class="card" style="padding: 0; overflow: hidden;">
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th style="width: 170px;">Waktu Transaksi</th>
                    <th>SKU &amp; Nama Produk</th>
                    <th style="text-align: center; width: 120px;">Jenis Mutasi</th>
                    <th style="text-align: center; width: 100px;">Jumlah</th>
                    <th>Petugas / User</th>
                    <th>Keterangan / Catatan</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $movements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td style="color: #64748b; font-size: 0.8125rem;">
                            <?php echo e($m->created_at->format('d/m/Y H:i:s')); ?>

                        </td>
                        <td>
                            <?php if($m->product): ?>
                                <a href="<?php echo e(route('products.show', $m->product)); ?>" style="color: #0f172a; font-weight: 600; text-decoration: none;">
                                    <span style="font-family: monospace; color: #3b82f6;">[<?php echo e($m->product->sku); ?>]</span> <?php echo e($m->product->name); ?>

                                </a>
                            <?php else: ?>
                                <span style="color: #94a3b8;">Produk Dihapus</span>
                            <?php endif; ?>
                        </td>
                        <td style="text-align: center;">
                            <?php if($m->type === 'IN'): ?>
                                <span class="badge badge-success">+ MASUK (IN)</span>
                            <?php else: ?>
                                <span class="badge badge-danger">- KELUAR (OUT)</span>
                            <?php endif; ?>
                        </td>
                        <td style="text-align: center; font-weight: 700; font-size: 0.95rem; color: <?php echo e($m->type === 'IN' ? '#16a34a' : '#dc2626'); ?>;">
                            <?php echo e($m->type === 'IN' ? '+' : '-'); ?><?php echo e($m->quantity); ?>

                        </td>
                        <td>
                            <span style="font-size: 0.8125rem; font-weight: 500; color: #475569;">
                                <?php echo e($m->user->name ?? 'System'); ?>

                            </span>
                        </td>
                        <td style="color: #475569; font-size: 0.8125rem;">
                            <?php echo e($m->notes ?? '-'); ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" style="text-align: center; color: #94a3b8; padding: 3rem 1rem;">
                            Belum ada histori transaksi mutasi stok.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div style="margin-top: 1rem;">
    <?php echo e($movements->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\nurul\.gemini\antigravity\scratch\inventory-laravel\resources\views/stock/history.blade.php ENDPATH**/ ?>