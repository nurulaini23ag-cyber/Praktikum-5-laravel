<nav style="background: #1e293b; color: #fff; padding: 0.75rem 1.5rem; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
    <div style="max-width: 1200px; margin: 0 auto; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 1rem;">
        <div style="display: flex; align-items: center; gap: 1.5rem;">
            <a href="<?php echo e(route('dashboard')); ?>" style="color: #fff; text-decoration: none; font-size: 1.25rem; font-weight: bold; display: flex; align-items: center; gap: 0.5rem;">
                📦 <span>Inventory System</span>
            </a>
            <div style="display: flex; gap: 0.75rem; font-size: 0.95rem;">
                <a href="<?php echo e(route('dashboard')); ?>" style="color: #cbd5e1; text-decoration: none; padding: 0.4rem 0.75rem; border-radius: 6px; <?php echo e(request()->routeIs('dashboard') ? 'background: #334155; color: #fff; font-weight: 600;' : ''); ?>">Dashboard</a>
                <a href="<?php echo e(route('products.index')); ?>" style="color: #cbd5e1; text-decoration: none; padding: 0.4rem 0.75rem; border-radius: 6px; <?php echo e(request()->routeIs('products.*') ? 'background: #334155; color: #fff; font-weight: 600;' : ''); ?>">Produk</a>
                <a href="<?php echo e(route('categories.index')); ?>" style="color: #cbd5e1; text-decoration: none; padding: 0.4rem 0.75rem; border-radius: 6px; <?php echo e(request()->routeIs('categories.*') ? 'background: #334155; color: #fff; font-weight: 600;' : ''); ?>">Kategori</a>
                <a href="<?php echo e(route('suppliers.index')); ?>" style="color: #cbd5e1; text-decoration: none; padding: 0.4rem 0.75rem; border-radius: 6px; <?php echo e(request()->routeIs('suppliers.*') ? 'background: #334155; color: #fff; font-weight: 600;' : ''); ?>">Supplier</a>
                <a href="<?php echo e(route('stock.history')); ?>" style="color: #cbd5e1; text-decoration: none; padding: 0.4rem 0.75rem; border-radius: 6px; <?php echo e(request()->routeIs('stock.*') ? 'background: #334155; color: #fff; font-weight: 600;' : ''); ?>">Mutasi Stok</a>
            </div>
        </div>
        <div style="display: flex; align-items: center; gap: 1rem;">
            <?php if(auth()->guard()->check()): ?>
                <span style="font-size: 0.875rem; background: #334155; padding: 0.35rem 0.75rem; border-radius: 9999px; color: #e2e8f0;">
                    👤 <?php echo e(auth()->user()->name); ?> (<?php echo e(strtoupper(auth()->user()->role ?? 'STAFF')); ?>)
                </span>
                <form action="<?php echo e(route('logout')); ?>" method="POST" style="margin: 0; display: inline;">
                    <?php echo csrf_field(); ?>
                    <button type="submit" style="background: #dc2626; color: #fff; border: none; padding: 0.4rem 0.85rem; border-radius: 6px; cursor: pointer; font-size: 0.875rem; font-weight: 500;">Logout</button>
                </form>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>" style="background: #2563eb; color: #fff; text-decoration: none; padding: 0.4rem 0.85rem; border-radius: 6px; font-size: 0.875rem; font-weight: 500;">Login</a>
            <?php endif; ?>
        </div>
    </div>
</nav>
<?php /**PATH C:\Users\nurul\.gemini\antigravity\scratch\inventory-laravel\resources\views/layouts/navigation.blade.php ENDPATH**/ ?>