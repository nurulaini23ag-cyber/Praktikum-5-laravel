<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['type' => 'info']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['type' => 'info']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $classMap = [
        'success' => 'background-color: #ecfdf5; color: #065f46; border: 1px solid #a7f3d0;',
        'error'   => 'background-color: #fef2f2; color: #991b1b; border: 1px solid #fecaca;',
        'danger'  => 'background-color: #fef2f2; color: #991b1b; border: 1px solid #fecaca;',
        'warning' => 'background-color: #fffbeb; color: #92400e; border: 1px solid #fde68a;',
        'info'    => 'background-color: #eff6ff; color: #1e40af; border: 1px solid #bfdbfe;',
    ];
    $style = $classMap[$type] ?? $classMap['info'];
?>

<div class="alert alert-<?php echo e($type); ?>" style="<?php echo e($style); ?> padding: 12px 16px; border-radius: 8px; margin-bottom: 16px; display: flex; align-items: center; justify-content: space-between; font-weight: 500;">
    <div><?php echo e($slot); ?></div>
</div>
<?php /**PATH C:\Users\nurul\.gemini\antigravity\scratch\inventory-laravel\resources\views/components/alert.blade.php ENDPATH**/ ?>