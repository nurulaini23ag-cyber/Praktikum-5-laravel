<?php $__env->startSection('content'); ?>
<div style="margin-bottom: 2rem;">
    <h1 style="font-size: 1.875rem; font-weight: 700; color: #0f172a; margin: 0 0 0.25rem 0;">Dashboard Inventaris</h1>
    <p style="color: #64748b; margin: 0; font-size: 0.95rem;">Ringkasan metrik statistik operasional sistem manajemen gudang.</p>
</div>

<!-- Stat Cards Widgets -->
<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 1.25rem; margin-bottom: 2rem;">
    <div class="card" style="margin-bottom: 0; border-left: 4px solid #2563eb;">
        <span style="font-size: 0.8125rem; color: #64748b; font-weight: 500;">TOTAL PRODUK</span>
        <div style="font-size: 1.875rem; font-weight: 700; color: #0f172a; margin-top: 0.25rem;"><?php echo e($totalProducts); ?></div>
        <div style="font-size: 0.75rem; color: #64748b; margin-top: 0.25rem;">SKU terdaftar di katalog</div>
    </div>

    <div class="card" style="margin-bottom: 0; border-left: 4px solid #16a34a;">
        <span style="font-size: 0.8125rem; color: #64748b; font-weight: 500;">VOLUME TOTAL STOK</span>
        <div style="font-size: 1.875rem; font-weight: 700; color: #16a34a; margin-top: 0.25rem;"><?php echo e(number_format($totalStock, 0, ',', '.')); ?></div>
        <div style="font-size: 0.75rem; color: #64748b; margin-top: 0.25rem;">Total kuantitas unit barang</div>
    </div>

    <div class="card" style="margin-bottom: 0; border-left: 4px solid #0891b2;">
        <span style="font-size: 0.8125rem; color: #64748b; font-weight: 500;">VALUASI ASET INVENTARIS</span>
        <div style="font-size: 1.6rem; font-weight: 700; color: #0891b2; margin-top: 0.25rem;">Rp <?php echo e(number_format($totalValue, 0, ',', '.')); ?></div>
        <div style="font-size: 0.75rem; color: #64748b; margin-top: 0.25rem;">Akumulasi nilai stok &times; harga</div>
    </div>

    <div class="card" style="margin-bottom: 0; border-left: 4px solid #dc2626;">
        <span style="font-size: 0.8125rem; color: #64748b; font-weight: 500;">PERINGATAN STOK MENIPIS</span>
        <div style="font-size: 1.875rem; font-weight: 700; color: #dc2626; margin-top: 0.25rem;"><?php echo e($lowStockCount); ?></div>
        <div style="font-size: 0.75rem; color: #64748b; margin-top: 0.25rem;">Barang &le; batas minimum</div>
    </div>
</div>

<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem;">
    <!-- Barang Stok Menipis -->
    <div class="card" style="padding: 0; overflow: hidden;">
        <div style="padding: 1rem 1.25rem; border-bottom: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center;">
            <h3 style="margin: 0; font-size: 1rem; font-weight: 600; color: #dc2626;">⚠️ Perhatian: Stok Menipis</h3>
            <a href="<?php echo e(route('products.index', ['stock_status' => 'low'])); ?>" style="font-size: 0.8125rem; color: #2563eb; text-decoration: none;">Lihat Semua &rarr;</a>
        </div>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>SKU</th>
                        <th>Nama Produk</th>
                        <th style="text-align: center;">Sisa</th>
                        <th style="text-align: center;">Min</th>
                        <th style="text-align: right;">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $lowStockProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td style="font-family: monospace; font-weight: 600;"><?php echo e($lp->sku); ?></td>
                            <td><?php echo e($lp->name); ?></td>
                            <td style="text-align: center; font-weight: 700; color: #dc2626;"><?php echo e($lp->stock); ?></td>
                            <td style="text-align: center;"><?php echo e($lp->minimum_stock); ?></td>
                            <td style="text-align: right;">
                                <a href="<?php echo e(route('stock.in')); ?>?product_id=<?php echo e($lp->id); ?>" class="btn btn-success" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;">+ Restock</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" style="text-align: center; color: #16a34a; padding: 2rem;">Semua stok dalam batas aman!</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- 5 Mutasi Terbaru -->
    <div class="card" style="padding: 0; overflow: hidden;">
        <div style="padding: 1rem 1.25rem; border-bottom: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center;">
            <h3 style="margin: 0; font-size: 1rem; font-weight: 600; color: #1e293b;">📋 Mutasi Stok Terakhir</h3>
            <a href="<?php echo e(route('stock.history')); ?>" style="font-size: 0.8125rem; color: #2563eb; text-decoration: none;">Lihat Histori &rarr;</a>
        </div>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Waktu</th>
                        <th>Produk</th>
                        <th style="text-align: center;">Tipe</th>
                        <th style="text-align: center;">Qty</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $recentMovements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td style="font-size: 0.8125rem; color: #64748b;"><?php echo e($rm->created_at->format('d/m H:i')); ?></td>
                            <td><?php echo e($rm->product->name ?? 'Produk'); ?></td>
                            <td style="text-align: center;">
                                <?php if($rm->type === 'IN'): ?>
                                    <span class="badge badge-success">+ IN</span>
                                <?php else: ?>
                                    <span class="badge badge-danger">- OUT</span>
                                <?php endif; ?>
                            </td>
                            <td style="text-align: center; font-weight: 600;"><?php echo e($rm->quantity); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4" style="text-align: center; color: #94a3b8; padding: 2rem;">Belum ada aktivitas mutasi stok.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\nurul\.gemini\antigravity\scratch\inventory-laravel\resources\views/dashboard.blade.php ENDPATH**/ ?>