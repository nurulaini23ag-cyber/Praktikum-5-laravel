<?php $__env->startSection('content'); ?>
<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem;">
    <div>
        <h1 style="font-size: 1.75rem; font-weight: 700; margin: 0 0 0.25rem 0; color: #0f172a;">Daftar Produk</h1>
        <p style="color: #64748b; margin: 0; font-size: 0.875rem;">Kelola seluruh inventaris, informasi stok, dan harga produk.</p>
    </div>
    <div style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
        <a href="<?php echo e(route('stock.in')); ?>" class="btn btn-success">+ Masuk Stok</a>
        <a href="<?php echo e(route('stock.out')); ?>" class="btn btn-danger">- Keluar Stok</a>
        <a href="<?php echo e(route('products.create')); ?>" class="btn btn-primary">+ Tambah Produk</a>
    </div>
</div>

<!-- Search, Filter, & Sorting Panel (Slide 32, 38) -->
<div class="card" style="padding: 1.25rem; margin-bottom: 1.5rem;">
    <form method="GET" action="<?php echo e(route('products.index')); ?>" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)) 100px; gap: 0.75rem; align-items: end;">
        <div>
            <label class="form-label">Cari Nama / SKU</label>
            <input type="text" name="search" class="form-control" placeholder="Ketik kata kunci..." value="<?php echo e(request('search')); ?>">
        </div>
        <div>
            <label class="form-label">Filter Kategori</label>
            <select name="category_id" class="form-select">
                <option value="">Semua Kategori</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($cat->id); ?>" <?php echo e(request('category_id') == $cat->id ? 'selected' : ''); ?>>
                        <?php echo e($cat->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div>
            <label class="form-label">Status Stok</label>
            <select name="stock_status" class="form-select">
                <option value="">Semua Status</option>
                <option value="low" <?php echo e(request('stock_status') == 'low' ? 'selected' : ''); ?>>Stok Menipis</option>
            </select>
        </div>
        <div>
            <label class="form-label">Urutkan</label>
            <select name="sort" class="form-select">
                <option value="name" <?php echo e(($sortBy ?? '') == 'name' ? 'selected' : ''); ?>>Nama Produk</option>
                <option value="sku" <?php echo e(($sortBy ?? '') == 'sku' ? 'selected' : ''); ?>>SKU</option>
                <option value="price" <?php echo e(($sortBy ?? '') == 'price' ? 'selected' : ''); ?>>Harga</option>
                <option value="stock" <?php echo e(($sortBy ?? '') == 'stock' ? 'selected' : ''); ?>>Jumlah Stok</option>
                <option value="created_at" <?php echo e(($sortBy ?? '') == 'created_at' ? 'selected' : ''); ?>>Terbaru</option>
            </select>
        </div>
        <div>
            <label class="form-label">Arah</label>
            <select name="order" class="form-select">
                <option value="asc" <?php echo e(($sortOrder ?? '') == 'asc' ? 'selected' : ''); ?>>A-Z / Rendah</option>
                <option value="desc" <?php echo e(($sortOrder ?? '') == 'desc' ? 'selected' : ''); ?>>Z-A / Tinggi</option>
            </select>
        </div>
        <div style="display: flex; gap: 0.35rem;">
            <button type="submit" class="btn btn-primary" style="width: 100%; justify-content: center;">Filter</button>
        </div>
    </form>
    <?php if(request()->hasAny(['search', 'category_id', 'stock_status', 'sort', 'order'])): ?>
        <div style="margin-top: 0.75rem; font-size: 0.8125rem;">
            <a href="<?php echo e(route('products.index')); ?>" style="color: #64748b; text-decoration: underline;">Reset Filter</a>
        </div>
    <?php endif; ?>
</div>

<!-- Table Data (Slide 24, 39) -->
<div class="card" style="padding: 0; overflow: hidden;">
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th style="width: 130px;">SKU</th>
                    <th>Nama Produk</th>
                    <th>Kategori</th>
                    <th style="text-align: right;">Harga (Rp)</th>
                    <th style="text-align: center;">Stok</th>
                    <th style="text-align: center;">Status</th>
                    <th style="text-align: right; width: 180px;">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td style="font-family: monospace; font-weight: 600; color: #3b82f6;">
                            <?php echo e($product->sku); ?>

                        </td>
                        <td>
                            <a href="<?php echo e(route('products.show', $product)); ?>" style="color: #0f172a; font-weight: 600; text-decoration: none;">
                                <?php echo e($product->name); ?>

                            </a>
                        </td>
                        <td>
                            <span class="badge badge-info"><?php echo e($product->category->name ?? 'Uncategorized'); ?></span>
                        </td>
                        <td style="text-align: right; font-weight: 500;">
                            Rp <?php echo e(number_format($product->price, 0, ',', '.')); ?>

                        </td>
                        <td style="text-align: center; font-weight: 600;">
                            <?php echo e($product->stock); ?>

                        </td>
                        <td style="text-align: center;">
                            <?php if($product->stock <= $product->minimum_stock): ?>
                                <span class="badge badge-danger">Menipis (&le; <?php echo e($product->minimum_stock); ?>)</span>
                            <?php else: ?>
                                <span class="badge badge-success">Aman</span>
                            <?php endif; ?>
                        </td>
                        <td style="text-align: right;">
                            <div style="display: flex; gap: 0.35rem; justify-content: flex-end;">
                                <a href="<?php echo e(route('products.show', $product)); ?>" class="btn btn-secondary" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;">Detail</a>
                                <a href="<?php echo e(route('products.edit', $product)); ?>" class="btn btn-secondary" style="padding: 0.25rem 0.5rem; font-size: 0.75rem; color: #2563eb;">Edit</a>
                                <form action="<?php echo e(route('products.destroy', $product)); ?>" method="POST" style="margin: 0;" onsubmit="return confirm('Apakah Anda yakin ingin menghapus produk ini?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;">Hapus</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 3rem 1rem; color: #94a3b8;">
                            <div style="font-size: 2.5rem; margin-bottom: 0.5rem;">📦</div>
                            <p style="margin: 0; font-size: 1rem; font-weight: 500;">Belum ada produk yang ditemukan.</p>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Pagination Links -->
<div style="margin-top: 1rem;">
    <?php echo e($products->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\nurul\.gemini\antigravity\scratch\inventory-laravel\resources\views/products/index.blade.php ENDPATH**/ ?>