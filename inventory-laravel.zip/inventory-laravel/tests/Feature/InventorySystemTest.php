<?php

namespace Tests\Feature;

use App\Models\Category;
use App\Models\Product;
use App\Models\StockMovement;
use App\Models\Supplier;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class InventorySystemTest extends TestCase
{
    use RefreshDatabase;

    public function test_category_and_product_eloquent_relationship()
    {
        $category = Category::factory()->create(['name' => 'Hardware']);
        $product = Product::factory()->create([
            'category_id' => $category->id,
            'name' => 'SSD NVMe 1TB',
            'sku' => 'SSD-001',
        ]);

        $this->assertEquals('Hardware', $product->category->name);
        $this->assertTrue($category->products->contains($product));
    }

    public function test_product_crud_flow_create_read_update_delete()
    {
        $category = Category::factory()->create();

        // 1. Open create form
        $response = $this->get(route('products.create'));
        $response->assertStatus(200);

        // 2. Validate required fields
        $invalidResponse = $this->post(route('products.store'), []);
        $invalidResponse->assertSessionHasErrors(['category_id', 'sku', 'name', 'price', 'stock']);

        // 3. Store valid product
        $storeResponse = $this->post(route('products.store'), [
            'category_id' => $category->id,
            'sku' => 'TEST-001',
            'name' => 'Test Gaming Mouse',
            'price' => 150000,
            'stock' => 20,
            'minimum_stock' => 5,
        ]);
        $storeResponse->assertRedirect(route('products.index'));
        $storeResponse->assertSessionHas('success');

        $this->assertDatabaseHas('products', [
            'sku' => 'TEST-001',
            'name' => 'Test Gaming Mouse',
            'stock' => 20,
        ]);

        $product = Product::where('sku', 'TEST-001')->first();

        // 4. Read product index with search
        $searchResponse = $this->get(route('products.index', ['search' => 'Gaming']));
        $searchResponse->assertStatus(200);
        $searchResponse->assertSee('Test Gaming Mouse');

        // 5. Update product
        $updateResponse = $this->put(route('products.update', $product), [
            'category_id' => $category->id,
            'sku' => 'TEST-001',
            'name' => 'Updated Gaming Mouse',
            'price' => 175000,
            'stock' => 25,
            'minimum_stock' => 5,
        ]);
        $updateResponse->assertRedirect(route('products.index'));
        $this->assertDatabaseHas('products', ['name' => 'Updated Gaming Mouse', 'stock' => 25]);
    }

    public function test_stock_in_transaction_increases_stock()
    {
        $category = Category::factory()->create();
        $product = Product::factory()->create(['category_id' => $category->id, 'stock' => 10]);

        $response = $this->post(route('stock.in.store'), [
            'product_id' => $product->id,
            'quantity' => 5,
            'notes' => 'Penerimaan stok tambahan',
        ]);

        $response->assertRedirect(route('products.index'));
        $this->assertEquals(15, $product->fresh()->stock);
        $this->assertDatabaseHas('stock_movements', [
            'product_id' => $product->id,
            'type' => 'IN',
            'quantity' => 5,
        ]);
    }

    public function test_stock_out_transaction_safe_and_prevents_negative_stock()
    {
        $category = Category::factory()->create();
        $product = Product::factory()->create(['category_id' => $category->id, 'stock' => 10]);

        // Attempt to withdraw more than available stock
        $failResponse = $this->post(route('stock.out.store'), [
            'product_id' => $product->id,
            'quantity' => 15,
            'notes' => 'Pengeluaran melebihi kapasitas',
        ]);

        $failResponse->assertSessionHas('error');
        $this->assertEquals(10, $product->fresh()->stock); // Stock remains intact

        // Valid withdrawal
        $successResponse = $this->post(route('stock.out.store'), [
            'product_id' => $product->id,
            'quantity' => 4,
            'notes' => 'Pengeluaran valid',
        ]);

        $successResponse->assertRedirect(route('products.index'));
        $this->assertEquals(6, $product->fresh()->stock);
        $this->assertDatabaseHas('stock_movements', [
            'product_id' => $product->id,
            'type' => 'OUT',
            'quantity' => 4,
        ]);
    }
}
